package com.example.grid;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import com.example.grid.AdapterImg.AdapterImage;

public class FullImage extends AppCompatActivity {

    ImageView imageView;
    AdapterImage adapterImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_image);
        imageView = findViewById(R.id.fullImg);

        // Obtener la posición de la imagen del intent
        Intent intent = getIntent();
        int position = intent.getIntExtra("position", -1);
        if (position != -1) {
            // Crear una nueva instancia de AdapterImage
            AdapterImage adapterImage = new AdapterImage(this);
            // Obtener el ID de recurso de la imagen utilizando la posición
            int resourceId = adapterImage.imageArray[position];
            imageView.setImageResource(resourceId);
        } else {
            // Manejar el caso en el que no se reciba la posición
        }
    }
}


