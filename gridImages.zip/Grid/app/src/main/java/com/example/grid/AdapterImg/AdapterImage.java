package com.example.grid.AdapterImg;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.example.grid.R;

public class AdapterImage extends BaseAdapter {

    private Context mContext;

    public int[] imageArray = {
            R.drawable.bola1, R.drawable.bola2, R.drawable.bola3,
            R.drawable.bola4, R.drawable.bola5, R.drawable.bola6,
            R.drawable.bola7, R.drawable.bola8, R.drawable.bola9,
            R.drawable.bola10,R.drawable.bola11,R.drawable.bola12,
            R.drawable.bola13,R.drawable.bola14,R.drawable.bola15,
            R.drawable.bola16,R.drawable.bola17,R.drawable.bola18,
            R.drawable.bola22,R.drawable.bola23,R.drawable.bola24,

    };

    public AdapterImage(Context mContext) {
        this.mContext = mContext;
    }
    @Override
    public int getCount() {
        return imageArray.length;
    }

    @Override
    public Object getItem(int i) {
        return imageArray[i];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {

        ImageView imageView = new ImageView(mContext);
        imageView.setImageResource(imageArray[i]);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setLayoutParams(new ViewGroup.LayoutParams(340, 350));

        return imageView;
    }
}
